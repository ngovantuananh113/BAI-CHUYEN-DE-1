<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

Route::get('/', function () {
    $productsCount = \App\Models\Product::count();
    $categoriesCount = \App\Models\Category::count();
    $latestProducts = \App\Models\Product::with('category')->latest()->take(5)->get();
    
    return view('dashboard', compact('productsCount', 'categoriesCount', 'latestProducts'));
})->name('dashboard');

Route::resource('products', ProductController::class);
