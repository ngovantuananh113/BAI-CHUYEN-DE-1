@extends('layouts.master')

@section('content')
<div class="glass-card">
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <h2>Danh Sách Sản Phẩm</h2>
        <a href="{{ route('products.create') }}" class="btn btn-primary">+ Thêm Sản Phẩm</a>
    </div>

    <form method="GET" action="{{ route('products.index') }}" style="display: flex; gap: 10px; margin-top: 1rem;">
        <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Tìm kiếm theo tên..." style="max-width: 300px;">
        <button type="submit" class="btn btn-secondary" style="border: 1px solid #ddd;">Tìm kiếm</button>
        <a href="{{ route('products.index') }}" class="btn" style="color: #666;">Xóa Lọc</a>
    </form>

    <table class="table">
        <thead>
            <tr>
                <th>Ảnh</th>
                <th>Tên SP</th>
                <th>Danh Mục</th>
                <th>
                    Giá 
                    <a href="{{ route('products.index', array_merge(request()->query(), ['sort' => request('sort') == 'asc' ? 'desc' : 'asc'])) }}" style="text-decoration:none; font-size: 0.8rem;">
                        {!! request('sort') == 'asc' ? '&#9650;' : '&#9660;' !!}
                    </a>
                </th>
                <th>Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            @foreach($products as $product)
            <tr>
                <td>
                    @if($product->image)
                        <img src="{{ Storage::url($product->image) }}" alt="img" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                    @endif
                </td>
                <td>{{ $product->name }}</td>
                <td>{{ $product->category->name }}</td>
                <td>{{ number_format($product->price) }}</td>
                <td>
                    <a href="{{ route('products.edit', $product->id) }}" class="btn" style="background:#f1c40f; color:#fff; padding:0.3rem 0.6rem;">Sửa</a>
                    <form action="{{ route('products.destroy', $product->id) }}" method="POST" style="display: inline-block;" onsubmit="return confirm('Chắc chắn xóa?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger" style="padding:0.3rem 0.6rem;">Xóa</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div style="margin-top: 2rem;">
        {{ $products->appends(request()->query())->links('pagination::bootstrap-4') }}
    </div>
</div>
@endsection
