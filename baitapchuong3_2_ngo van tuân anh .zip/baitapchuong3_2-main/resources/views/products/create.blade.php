@extends('layouts.master')

@section('content')
<div class="glass-card" style="max-width: 600px; margin: 2rem auto;">
    <h2>Thêm Sản Phẩm Mới</h2>
    
    <form action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label>Tên sản phẩm *</label>
            <input type="text" name="name" class="form-control" value="{{ old('name') }}" required>
        </div>
        
        <div class="form-group">
            <label>Danh mục *</label>
            <select name="category_id" class="form-control" required>
                <option value="">Chọn danh mục...</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label>Giá (VND) *</label>
            <input type="number" name="price" class="form-control" value="{{ old('price') }}" required>
        </div>

        <div class="form-group">
            <label>Số lượng *</label>
            <input type="number" name="quantity" class="form-control" value="{{ old('quantity') }}" required>
        </div>

        <div class="form-group">
            <label>Ảnh sản phẩm</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>

        <div style="display: flex; justify-content: space-between; margin-top: 2rem;">
            <a href="{{ route('products.index') }}" class="btn" style="background:#bdc3c7; color:#fff;">Hủy</a>
            <button type="submit" class="btn btn-success">Lưu Sản Phẩm</button>
        </div>
    </form>
</div>
@endsection
