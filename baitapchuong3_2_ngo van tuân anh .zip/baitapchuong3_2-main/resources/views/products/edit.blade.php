@extends('layouts.master')

@section('content')
<div class="glass-card" style="max-width: 600px; margin: 2rem auto;">
    <h2>Sửa Sản Phẩm: {{ $product->name }}</h2>
    
    <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        
        <div class="form-group">
            <label>Tên sản phẩm *</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $product->name) }}" required>
        </div>
        
        <div class="form-group">
            <label>Danh mục *</label>
            <select name="category_id" class="form-control" required>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" {{ old('category_id', $product->category_id) == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label>Giá (VND) *</label>
            <input type="number" name="price" class="form-control" value="{{ old('price', $product->price) }}" required>
        </div>

        <div class="form-group">
            <label>Số lượng *</label>
            <input type="number" name="quantity" class="form-control" value="{{ old('quantity', $product->quantity) }}" required>
        </div>

        <div class="form-group">
            <label>Ảnh sản phẩm hiện tại</label>
            @if($product->image)
                <div style="margin-bottom: 10px;">
                    <img src="{{ Storage::url($product->image) }}" alt="Preview" style="height: 100px; border-radius: 8px;">
                </div>
            @endif
            <input type="file" name="image" class="form-control" accept="image/*">
            <small style="color: #666;">Chọn ảnh mới để thay thế ảnh cũ.</small>
        </div>

        <div style="display: flex; justify-content: space-between; margin-top: 2rem;">
            <a href="{{ route('products.index') }}" class="btn" style="background:#bdc3c7; color:#fff;">Hủy</a>
            <button type="submit" class="btn btn-primary">Cập Nhật</button>
        </div>
    </form>
</div>
@endsection
