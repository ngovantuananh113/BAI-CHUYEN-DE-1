@extends('layouts.master')

@section('content')
<div class="glass-card">
    <h2>Dashboard Tổng Quan</h2>
    <div class="dashboard-stats">
        <div class="stat-box">
            <h3>{{ $productsCount }}</h3>
            <p>Tổng Sản Phẩm</p>
        </div>
        <div class="stat-box" style="background: linear-gradient(135deg, #2ecc71, #27ae60);">
            <h3>{{ $categoriesCount }}</h3>
            <p>Tổng Danh Mục</p>
        </div>
    </div>

    <h3>5 Sản Phẩm Mới Nhất</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Ảnh</th>
                <th>Tên SP</th>
                <th>Danh Mục</th>
                <th>Giá</th>
                <th>Tồn Kho</th>
            </tr>
        </thead>
        <tbody>
            @forelse($latestProducts as $product)
            <tr>
                <td>
                    @if($product->image)
                        <img src="{{ Storage::url($product->image) }}" alt="{{ $product->name }}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                    @else
                        X
                    @endif
                </td>
                <td>{{ $product->name }}</td>
                <td>{{ $product->category->name ?? 'N/A' }}</td>
                <td>{{ number_format($product->price) }} VND</td>
                <td>{{ $product->quantity }}</td>
            </tr>
            @empty
            <tr>
                <td colspan="5" style="text-align: center;">Chưa có sản phẩm nào.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
