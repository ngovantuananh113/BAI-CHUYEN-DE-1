<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Category;
use App\Models\Product;

if (Category::count() == 0) {
    $c1 = Category::create(['name' => 'Điện Thoại']);
    $c2 = Category::create(['name' => 'Laptop']);
    Category::create(['name' => 'Phụ Kiện']);
    Product::create(['name' => 'iPhone 15 Pro', 'price' => 28000000, 'quantity' => 10, 'category_id' => $c1->id]);
    Product::create(['name' => 'MacBook Air M2', 'price' => 25000000, 'quantity' => 5, 'category_id' => $c2->id]);
    Product::create(['name' => 'Samsung Galaxy S24', 'price' => 24000000, 'quantity' => 8, 'category_id' => $c1->id]);
    echo "Seed done.\n";
} else {
    echo "Already seeded.\n";
}
